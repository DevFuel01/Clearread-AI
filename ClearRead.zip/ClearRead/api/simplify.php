<?php

/**
 * ClearRead AI - API Endpoint
 * Processes complex text using Google Gemini API
 */

// Include configuration
require_once '../config.php';

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
    exit();
}

/**
 * Send error response
 */
function sendError($message, $code = 400)
{
    http_response_code($code);
    echo json_encode([
        'success' => false,
        'error' => $message
    ]);
    exit();
}

/**
 * Send success response
 */
function sendSuccess($data)
{
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'result' => $data
    ]);
    exit();
}

// Check if API key is configured
if (!isApiKeyConfigured()) {
    sendError('API key not configured. Please add your Google Gemini API key to config.php', 500);
}

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['text']) || empty(trim($input['text']))) {
    sendError('Please provide text to simplify.');
}

$userText = trim($input['text']);

// Validate text length
if (strlen($userText) < MIN_INPUT_LENGTH) {
    sendError('Text is too short. Please provide at least ' . MIN_INPUT_LENGTH . ' characters.');
}

if (strlen($userText) > MAX_INPUT_LENGTH) {
    sendError('Text is too long. Maximum ' . MAX_INPUT_LENGTH . ' characters allowed.');
}

// Construct the prompt for Gemini
$prompt = buildPrompt($userText);

// Call Gemini API
try {
    $result = callGeminiAPI($prompt);
    sendSuccess($result);
} catch (Exception $e) {
    sendError($e->getMessage(), 500);
}

/**
 * Build the prompt for Gemini API
 */
function buildPrompt($text)
{
    return "You are ClearRead AI, an assistant that helps people in underrepresented and local communities understand complex documents.

Your task is to analyze the following text and provide a response in THREE clearly separated sections.

CRITICAL: You MUST include ALL THREE sections in your response, even if brief.

1. Simple Explanation:
Explain what this document is about in very simple, clear language that anyone can understand. Avoid jargon and technical terms. Use short sentences.

2. Key Points:
List the most important information from the document as bullet points. Focus on facts, dates, amounts, requirements, or deadlines that matter. Use bullet points starting with a dash (-).

3. What You Should Do Next:
Provide clear, actionable next steps. Tell the reader exactly what they should do (e.g., Apply, Respond, or Prepare specific documents). 
IMPORTANT: If the document is purely informational and requires NO action, explicitly state \"No action needed\" or \"For your information only - you can ignore this notice.\" 
Use bullet points starting with a dash (-).

FORMATTING RULES:
- Start each section with EXACTLY this text: 'Simple Explanation', 'Key Points', 'What You Should Do Next'
- Put each section header on its own line
- Leave a blank line after each header
- For Key Points and Next Steps, use bullet points (one per line, starting with -)
- Be concise but complete
- Use simple, everyday language

Here is the text to analyze:

---
$text
---

Please provide your response now with ALL THREE sections:";
}

/**
 * Call Google Gemini API
 */
function callGeminiAPI($prompt)
{
    $url = GEMINI_API_ENDPOINT . '?key=' . GEMINI_API_KEY;

    $data = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt]
                ]
            ]
        ],
        'generationConfig' => [
            'temperature' => 0.4,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 2048,
        ]
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
            'timeout' => 60,
            'ignore_errors' => true
        ]
    ];

    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        $error = error_get_last();
        throw new Exception('Failed to connect to AI service. Please check your internet connection and try again.');
    }

    $responseData = json_decode($response, true);

    // Check for API errors
    if (isset($responseData['error'])) {
        $errorMsg = $responseData['error']['message'] ?? 'Unknown API error';
        throw new Exception('AI service error: ' . $errorMsg);
    }

    if (!isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
        throw new Exception('Invalid response from AI service. Please try again.');
    }

    $aiResponse = $responseData['candidates'][0]['content']['parts'][0]['text'];

    // Parse the AI response into structured sections
    return parseAIResponse($aiResponse);
}

/**
 * Parse AI response into structured sections
 */
function parseAIResponse($response)
{
    $sections = [
        'simple_explanation' => '',
        'key_points' => '',
        'next_steps' => ''
    ];

    // Clean up the response
    $response = trim($response);

    // Split response into lines for processing
    $lines = explode("\n", $response);
    $currentSection = '';
    $sectionContent = ['simple_explanation' => [], 'key_points' => [], 'next_steps' => []];

    foreach ($lines as $line) {
        $line = trim($line);

        // Skip empty lines between sections
        if (empty($line)) {
            continue;
        }

        // Check for section headers
        if (preg_match('/^(?:1\.\s*)?Simple Explanation:?$/i', $line)) {
            $currentSection = 'simple_explanation';
            continue;
        } elseif (preg_match('/^(?:2\.\s*)?Key Points:?$/i', $line)) {
            $currentSection = 'key_points';
            continue;
        } elseif (preg_match('/^(?:3\.\s*)?What You Should Do Next:?$/i', $line)) {
            $currentSection = 'next_steps';
            continue;
        }

        // Add content to current section
        if (!empty($currentSection)) {
            $sectionContent[$currentSection][] = $line;
        }
    }

    // Join the content for each section
    foreach ($sectionContent as $key => $content) {
        if (!empty($content)) {
            $sections[$key] = implode("\n", $content);
        }
    }

    // Fallback parsing if line-by-line didn't work
    if (empty($sections['simple_explanation']) && empty($sections['key_points']) && empty($sections['next_steps'])) {
        // Try regex-based extraction
        if (preg_match('/Simple Explanation:?\s*(.*?)(?=Key Points:|What You Should Do Next:|$)/is', $response, $matches)) {
            $sections['simple_explanation'] = trim($matches[1]);
        }
        if (preg_match('/Key Points:?\s*(.*?)(?=What You Should Do Next:|$)/is', $response, $matches)) {
            $sections['key_points'] = trim($matches[1]);
        }
        if (preg_match('/What You Should Do Next:?\s*(.*?)$/is', $response, $matches)) {
            $sections['next_steps'] = trim($matches[1]);
        }
    }

    // Final fallback: use entire response
    if (empty($sections['simple_explanation']) && empty($sections['key_points']) && empty($sections['next_steps'])) {
        $sections['simple_explanation'] = $response;
        $sections['key_points'] = 'Please review the explanation above for important details.';
        $sections['next_steps'] = 'Take appropriate action based on the information provided.';
    }

    // Ensure no section is empty
    if (empty($sections['simple_explanation'])) {
        $sections['simple_explanation'] = 'Please see the key points below.';
    }
    if (empty($sections['key_points'])) {
        $sections['key_points'] = 'See the explanation above for details.';
    }
    if (empty($sections['next_steps'])) {
        $sections['next_steps'] = 'Review the information and take appropriate action.';
    }

    return $sections;
}
