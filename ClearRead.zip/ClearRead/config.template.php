<?php

/**
 * ClearRead AI - Configuration File Template
 * 
 * SETUP INSTRUCTIONS:
 * 1. Copy this file and rename it to: config.php
 * 2. Get your Google Gemini API key from: https://makersuite.google.com/app/apikey
 * 3. Replace 'YOUR_GEMINI_API_KEY_HERE' below with your actual API key
 * 4. Save the file
 * 5. Test the application at http://localhost/ClearRead
 */

// Error Reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Google Gemini API Configuration
// REPLACE THE VALUE BELOW WITH YOUR ACTUAL API KEY
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY_HERE');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// Application Settings
define('MAX_INPUT_LENGTH', 10000); // Maximum characters for input text
define('MIN_INPUT_LENGTH', 20);    // Minimum characters for input text

// CORS Settings (adjust for production)
define('ALLOWED_ORIGINS', ['http://localhost', 'http://127.0.0.1']);

// Timezone
date_default_timezone_set('UTC');

/**
 * Check if API key is configured
 */
function isApiKeyConfigured()
{
    return GEMINI_API_KEY !== 'YOUR_GEMINI_API_KEY_HERE' && !empty(GEMINI_API_KEY);
}
