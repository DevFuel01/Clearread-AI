# ClearRead AI 🚀

**Turn confusing documents into clear actions in seconds.**

ClearRead AI is a powerful, privacy-first web application designed to help people in underrepresented and local communities navigate complex documents. Built with **Google Gemini AI**, it transforms intimidating jargon—from government notices to school letters—into simple, actionable guidance.

## 🎯 Purpose

In a world governed by complex legal and administrative language, many community members feel overwhelmed or excluded. ClearRead AI levels the playing field by distilling any document into three essential parts:
- **Simple Explanation**: A warm, jargon-free summary (written at a 5th-grade reading level).
- **Key Points**: A high-contrast list of the most critical facts, dates, and requirements.
- **What You Should Do Next**: Clear, concrete action steps (Apply, Respond, or even "Ignore" if no action is needed).

## ✨ Features

- **Privacy-Respecting by Design**: 100% stateless. No data storage, no user tracking, no session persistence.
- **High-Speed Analysis**: Optimized using the **Gemini 2.5 Flash** model for near-instant results.
- **Robust Parsing Engine**: Built-in 3-layer fallback logic (Line-by-line -> Regex -> Raw) to ensure reliable responses.
- **Accessibility-First UI**: High-contrast text, large touch targets, and ARIA-compliant structure.
- **Zero Friction**: Single-page design. No login, no forms, no barriers.
- **Mobile-Responsive**: Looks and works perfectly on low-end mobile devices and tablets.

## 🛠️ Tech Stack

- **Frontend**: Vanilla HTML5, CSS3 (Modern Flexbox/Grid), JavaScript
- **Backend**: Secure PHP 7.4+ processing layer
- **AI Engine**: Google Gemini 2.5 Flash API (Fine-tuned via system instructions)
- **Infrastructure**: Apache/XAMPP optimized for local and cloud deployment

## 📋 Requirements

- XAMPP (or any Apache + PHP server)
- Internet connection (for AI analysis)
- Google Gemini API key ([Get one here](https://makersuite.google.com/app/apikey))

## 🚀 Setup Instructions

1. **Copy to htdocs**: Place the `ClearRead` folder in `C:\xampp\htdocs\ClearRead`.
2. **Configure Key**: Rename `config.template.php` to `config.php` and paste your Gemini API key:
   ```php
   define('GEMINI_API_KEY', 'your-api-key-here');
   ```
3. **Start Apache**: Turn on Apache in the XAMPP Control Panel.
4. **Launch**: Visit `http://localhost/ClearRead` in your browser.

## 📖 Usage Guide

1. **Paste**: Paste any confusing text (Legal, Medical, School, Government).
2. **Simplify**: Click the primary action button.
3. **Action**: Read your "Action Guidance" and know exactly what to do next.
4. **Reset**: Click "Simplify Another Document" to clear the state immediately.

## 🎬 Demo Script (Judges' Choice) 🏆

*Keep your demo under 60 seconds with these high-impact steps:*

1. **The Hook**: "Official notices are designed for lawyers, not families. ClearRead AI fixes that."
2. **The Paste**: Paste the **Property Tax Assessment** sample (see below).
3. **The Magic**: Click "Simplify" and point out the **Real-Time Spinner** (shows responsiveness).
4. **The Value**:
   - "Look at the **Simple Explanation**—it removed every legal jargon word."
   - "See the **Key Points**? It found the 30-day appeal deadline automatically."
   - "The **Next Steps** tell us exactly which form to file. No more guessing."
5. **The Closer**: "It’s stateless, private, and works on a $50 smartphone. This is AI for the community."

### Sample Text for Demo
> "NOTICE OF PROPERTY TAX ASSESSMENT ADJUSTMENT. Pursuant to Section 1603(b) of the Municipal Revenue Code, your property located at 123 Main Street has been reassessed. The assessed valuation has been adjusted to $268,500. Property owners have the right to appeal this assessment within thirty (30) calendar days by filing Form PT-467 with the Appeals Board. Failure to remit payment by the due date may result in penalties of 1.5% per month."

## 🔒 Security & Peace of Mind

- ✅ **Stateless**: Your documents are never saved to a database or disk.
- ✅ **Secure Endpoint**: Backend validation blocks malicious or overly large inputs.
- ✅ **API Protection**: Configuration is shielded via `.htaccess` to prevent key exposure.
- ✅ **XSS Protection**: Automatic HTML escaping on all AI-returned content.

## � Social Impact

ClearRead AI empowers the most vulnerable members of our community:
- **Non-Native Speakers**: Translates complex "Legalese" into plain English.
- **Struggling Readers**: Removes the barrier of complex sentence structures.
- **Busy Families**: Extracts actions in seconds, preventing costly missed deadlines.

---

**Built with ❤️ for a more accessible world.**

