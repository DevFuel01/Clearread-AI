<?php

/**
 * ClearRead AI - Configuration File
 * Store your Google Gemini API key and other settings here
 */

// Error Reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Google Gemini API Configuration
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY_HERE');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// Application Settings
define('MAX_INPUT_LENGTH', 10000); // Maximum characters for input text
define('MIN_INPUT_LENGTH', 20);    // Minimum characters for input text

// CORS Settings (adjust for production)
define('ALLOWED_ORIGINS', ['http://localhost', 'http://127.0.0.1']);

// Timezone
date_default_timezone_set('UTC');

/**
 * Check if API key is configured
 */
function isApiKeyConfigured()
{
    return GEMINI_API_KEY !== 'YOUR_GEMINI_API_KEY_HERE' && !empty(GEMINI_API_KEY);
}
