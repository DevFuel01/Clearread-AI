/**
 * ClearRead AI - Frontend JavaScript
 * Handles user interaction and API communication
 */

// DOM Elements
const complexTextInput = document.getElementById('complex-text');
const simplifyBtn = document.getElementById('simplify-btn');
const loadingIndicator = document.getElementById('loading-indicator');
const errorMessage = document.getElementById('error-message');
const errorText = document.getElementById('error-text');
const outputSection = document.getElementById('output-section');
const simpleExplanation = document.getElementById('simple-explanation');
const keyPoints = document.getElementById('key-points');
const nextSteps = document.getElementById('next-steps');
const tryAgainBtn = document.getElementById('try-again-btn');

// Event Listeners
simplifyBtn.addEventListener('click', handleSimplify);
tryAgainBtn.addEventListener('click', resetForm);

// Allow Enter key in textarea (Shift+Enter for new line)
complexTextInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
        e.preventDefault();
        handleSimplify();
    }
});

/**
 * Main function to handle text simplification
 */
async function handleSimplify() {
    const inputText = complexTextInput.value.trim();
    
    // Validate input
    if (!inputText) {
        showError('Please paste some text to simplify.');
        return;
    }
    
    if (inputText.length < 20) {
        showError('Please provide a longer text for better analysis.');
        return;
    }
    
    // Reset UI
    hideError();
    hideOutput();
    showLoading();
    disableButton();
    
    try {
        // Send request to backend
        const response = await fetch('api/simplify.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: inputText
            })
        });
        
        // Parse response
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to process your request');
        }
        
        if (data.success && data.result) {
            displayResult(data.result);
        } else {
            throw new Error(data.error || 'Invalid response from server');
        }
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Something went wrong. Please try again.');
    } finally {
        hideLoading();
        enableButton();
    }
}

/**
 * Display the AI-generated result
 */
function displayResult(result) {
    // Populate Simple Explanation
    if (result.simple_explanation) {
        simpleExplanation.innerHTML = formatText(result.simple_explanation);
    }
    
    // Populate Key Points
    if (result.key_points) {
        keyPoints.innerHTML = formatList(result.key_points);
    }
    
    // Populate Next Steps
    if (result.next_steps) {
        nextSteps.innerHTML = formatList(result.next_steps);
    }
    
    // Show output section with animation
    showOutput();
    
    // Scroll to results
    setTimeout(() => {
        outputSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

/**
 * Format text with paragraphs
 */
function formatText(text) {
    if (!text) return '';
    
    // Split by double newlines for paragraphs
    const paragraphs = text.split('\n\n').filter(p => p.trim());
    
    if (paragraphs.length > 1) {
        return paragraphs.map(p => `<p>${escapeHtml(p.trim())}</p>`).join('');
    }
    
    return `<p>${escapeHtml(text.trim())}</p>`;
}

/**
 * Format text as bullet list
 */
function formatList(text) {
    if (!text) return '';
    
    // Check if already formatted as list
    const lines = text.split('\n').filter(line => line.trim());
    
    // If text contains bullet points or numbers, parse them
    const listItems = lines.map(line => {
        // Remove common bullet point characters
        let cleaned = line.trim().replace(/^[-•*]\s*/, '').replace(/^\d+\.\s*/, '');
        return cleaned;
    }).filter(item => item);
    
    if (listItems.length > 0) {
        const items = listItems.map(item => `<li>${escapeHtml(item)}</li>`).join('');
        return `<ul>${items}</ul>`;
    }
    
    return `<p>${escapeHtml(text)}</p>`;
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Show loading indicator
 */
function showLoading() {
    loadingIndicator.classList.remove('hidden');
}

/**
 * Hide loading indicator
 */
function hideLoading() {
    loadingIndicator.classList.add('hidden');
}

/**
 * Show error message
 */
function showError(message) {
    errorText.textContent = message;
    errorMessage.classList.remove('hidden');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        hideError();
    }, 5000);
}

/**
 * Hide error message
 */
function hideError() {
    errorMessage.classList.add('hidden');
}

/**
 * Show output section
 */
function showOutput() {
    outputSection.classList.remove('hidden');
}

/**
 * Hide output section
 */
function hideOutput() {
    outputSection.classList.add('hidden');
}

/**
 * Disable simplify button
 */
function disableButton() {
    simplifyBtn.disabled = true;
    simplifyBtn.textContent = 'Processing...';
}

/**
 * Enable simplify button
 */
function enableButton() {
    simplifyBtn.disabled = false;
    simplifyBtn.textContent = 'Simplify Text';
}

/**
 * Reset form to initial state
 */
function resetForm() {
    complexTextInput.value = '';
    hideOutput();
    hideError();
    complexTextInput.focus();
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Initialize app
 */
function init() {
    // Focus on textarea on load
    complexTextInput.focus();
    
    // Add visual feedback for textarea
    complexTextInput.addEventListener('input', () => {
        if (complexTextInput.value.trim()) {
            simplifyBtn.style.opacity = '1';
        } else {
            simplifyBtn.style.opacity = '0.8';
        }
    });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
